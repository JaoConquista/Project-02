* Recurso de textos MarkDown

* Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora enim ullam beatae obcaecati tempore, eveniet quisquam porro qui, temporibus corrupti molestias, laborum incidunt velit nam maiores dicta odit dolore. Earum.

        -- Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora enim ullam beatae obcaecati tempore, eveniet quisquam porro qui, temporibus corrupti molestias, laborum incidunt velit nam maiores dicta odit dolore. Earum.
        